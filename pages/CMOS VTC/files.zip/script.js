// ═══════════════════════════════════════════
//   CMOS INVERTER SIMULATOR — SCRIPT
//   Exact Analytical Square-Law Model
// ═══════════════════════════════════════════

// ── GLOBAL CONSTANTS ──
const C_LOAD = 1.0;  // pF
const DT     = 0.01; // ns timestep

// Region color map
const REGION_COLORS = {
    'Region A': '#94a3b8',
    'Region B': '#facc15',
    'Region C': '#c084fc',
    'Region D': '#fb923c',
    'Region E': '#38bdf8',
};

// ── PHYSICS FUNCTIONS ──

function calculateVm(Vdd, Vtn, Vtp, Kr) {
    return (Vdd - Vtp + Vtn * Math.sqrt(Kr)) / (1 + Math.sqrt(Kr));
}

function generateAnalyticalVTC(Vdd, Vtn, Vtp, Kr) {
    const data = [];
    const Vm = calculateVm(Vdd, Vtn, Vtp, Kr);
    const Vout_max = Vm + Vtp;
    const Vout_min = Vm - Vtn;

    const STEP = 0.02;

    for (let vin = 0; vin <= Vdd + STEP; vin += STEP) {
        const v = Math.round(vin * 100) / 100;

        if (v < Vtn) {
            // Region A: NMOS Cutoff, PMOS Linear
            data.push({ x: v, y: Vdd });

        } else if (v < Vm - 0.01) {
            // Region B: NMOS Saturation, PMOS Linear
            const a = 0.5;
            const b = -(Vdd - v - Vtp);
            const c = 0.5 * Kr * Math.pow(v - Vtn, 2);
            const disc = b * b - 4 * a * c;
            if (disc >= 0) {
                const x = (-b - Math.sqrt(disc)) / (2 * a);
                data.push({ x: v, y: Vdd - x });
            }

        } else if (v >= Vm - 0.01 && v <= Vm + 0.01) {
            // Region C: Both Saturation — vertical drop
            if (data.length > 0 && data[data.length - 1].x !== Vm) {
                data.push({ x: Vm, y: Vout_max });
                data.push({ x: Vm, y: Vout_min });
            }

        } else if (v > Vm + 0.01 && v <= Vdd - Vtp) {
            // Region D: NMOS Linear, PMOS Saturation
            const a = 1;
            const b = -2 * (v - Vtn);
            const c = (1 / Kr) * Math.pow(Vdd - v - Vtp, 2);
            const disc = b * b - 4 * a * c;
            if (disc >= 0) {
                const vout = (-b - Math.sqrt(disc)) / (2 * a);
                data.push({ x: v, y: vout });
            }

        } else if (v > Vdd - Vtp) {
            // Region E: NMOS Linear, PMOS Cutoff
            data.push({ x: v, y: 0 });
        }
    }
    return data;
}

// Transient current models
function getNmosI(Vgs, Vds, Vtn, Kn) {
    if (Vgs < Vtn) return 0;
    if (Vds <= Vgs - Vtn)
        return Kn * (Vgs - Vtn - Vds / 2) * Vds;
    return 0.5 * Kn * Math.pow(Vgs - Vtn, 2);
}
function getPmosI(Vin, Vout, Vdd, Vtp, Kp) {
    const Vsg = Vdd - Vin;
    const Vsd = Vdd - Vout;
    if (Vsg < Vtp) return 0;
    if (Vsd <= Vsg - Vtp)
        return Kp * (Vsg - Vtp - Vsd / 2) * Vsd;
    return 0.5 * Kp * Math.pow(Vsg - Vtp, 2);
}

// ── CHART DEFAULTS ──
Chart.defaults.color = '#6b7f9e';
Chart.defaults.borderColor = '#1e2d47';
Chart.defaults.font.family = "'JetBrains Mono', monospace";
Chart.defaults.font.size   = 11;

const CHART_OPTIONS_BASE = (xLabel, yLabel) => ({
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
        legend: { display: false },
        tooltip: {
            backgroundColor: '#0d1220',
            borderColor: '#1e2d47',
            borderWidth: 1,
            padding: 10,
            titleColor: '#6b7f9e',
            bodyColor: '#dde4f0',
            callbacks: {
                label: ctx => ` ${ctx.dataset.label}: ${ctx.parsed.y?.toFixed(3)} V`
            }
        }
    },
    scales: {
        x: {
            type: 'linear',
            title: { display: true, text: xLabel, color: '#6b7f9e', padding: { top: 8 } },
            grid: { color: '#1e2d47' },
            ticks: { color: '#6b7f9e' },
        },
        y: {
            title: { display: true, text: yLabel, color: '#6b7f9e' },
            grid: { color: '#1e2d47' },
            ticks: { color: '#6b7f9e' },
            min: 0,
        }
    }
});

// ── CHART INIT ──
const vtcCtx = document.getElementById('vtcChart').getContext('2d');
const vtcChart = new Chart(vtcCtx, {
    type: 'line',
    data: {
        datasets: [
            {
                label: 'Vout',
                borderColor: '#38bdf8',
                borderWidth: 2.5,
                pointRadius: 0,
                tension: 0.1,
                fill: false,
                data: []
            },
            {
                label: 'Operating Point',
                type: 'bubble',
                backgroundColor: 'rgba(192,132,252,0.25)',
                borderColor: '#c084fc',
                borderWidth: 2,
                data: []
            }
        ]
    },
    options: {
        ...CHART_OPTIONS_BASE('Vin (V)', 'Vout (V)'),
        plugins: {
            ...CHART_OPTIONS_BASE().plugins,
            annotation: undefined,
        }
    }
});

const transCtx = document.getElementById('transientChart').getContext('2d');
const transChart = new Chart(transCtx, {
    type: 'line',
    data: {
        datasets: [
            {
                label: 'Vin (Input)',
                borderColor: '#c084fc',
                borderWidth: 2,
                borderDash: [5, 4],
                pointRadius: 0,
                tension: 0.05,
                data: []
            },
            {
                label: 'Vout (Output)',
                borderColor: '#38bdf8',
                borderWidth: 2.5,
                pointRadius: 0,
                tension: 0.2,
                data: []
            }
        ]
    },
    options: CHART_OPTIONS_BASE('Time (ns)', 'Voltage (V)')
});

// ── STATE DISPLAY ──
function getRegionForVin(Vin_op, Vtn, Vtp, Vdd, Vm) {
    if (Vin_op < Vtn)              return { region: 'Region A', nmos: 'Cutoff',     pmos: 'Linear'     };
    if (Vin_op > Vdd - Vtp)        return { region: 'Region E', nmos: 'Linear',     pmos: 'Cutoff'     };
    if (Math.abs(Vin_op - Vm) <= 0.01)
                                   return { region: 'Region C', nmos: 'Saturation', pmos: 'Saturation' };
    if (Vin_op < Vm)               return { region: 'Region B', nmos: 'Saturation', pmos: 'Linear'     };
    return                                { region: 'Region D', nmos: 'Linear',     pmos: 'Saturation' };
}

function setStateDisplay(region, nmosState, pmosState) {
    const nEl = document.getElementById('nmos-region');
    const pEl = document.getElementById('pmos-region');
    const rEl = document.getElementById('current-region');

    nEl.textContent = nmosState;
    pEl.textContent = pmosState;
    rEl.textContent = region;

    nEl.style.color = nmosState === 'Cutoff' ? 'var(--text-muted)' : 'var(--nmos)';
    pEl.style.color = pmosState === 'Cutoff' ? 'var(--text-muted)' : 'var(--pmos)';

    const col = REGION_COLORS[region] || 'var(--vin)';
    rEl.style.color = col;
}

// ── TRANSIENT SIMULATION ──
function runTransient(Vdd, Vtn, Vtp, Kn, Kp, mode) {
    const transVin  = [];
    const transVout = [];
    let vout_t = Vdd;

    for (let t = 0; t <= 10; t += DT) {
        let vin_t = 0;
        if (mode === 'pulse') {
            if      (t < 1)   vin_t = 0;
            else if (t < 1.5) vin_t = Vdd * ((t - 1) / 0.5);
            else if (t < 5)   vin_t = Vdd;
            else if (t < 5.5) vin_t = Vdd * (1 - (t - 5) / 0.5);
            else              vin_t = 0;
        } else {
            vin_t = (t / 10) * Vdd;
        }

        const In = getNmosI(vin_t, vout_t, Vtn, Kn);
        const Ip = getPmosI(vin_t, vout_t, Vdd, Vtp, Kp);
        vout_t += ((Ip - In) / C_LOAD) * DT;
        vout_t = Math.max(0, Math.min(Vdd, vout_t));

        // Decimate: store every 5th sample
        if (Math.round(t * 100) % 5 === 0) {
            transVin.push({ x: +t.toFixed(3), y: +vin_t.toFixed(4) });
            transVout.push({ x: +t.toFixed(3), y: +vout_t.toFixed(4) });
        }
    }
    return { transVin, transVout };
}

// ── MAIN UPDATE ──
function updateSimulation() {
    // Read params
    const Vdd = parseFloat(document.getElementById('vdd').value);
    const Vtn = parseFloat(document.getElementById('vtn').value);
    const Vtp = parseFloat(document.getElementById('vtp').value);
    const Kr  = parseFloat(document.getElementById('kr').value);
    const Kp  = 1.0;
    const Kn  = Kr * Kp;
    let   Vin_op = parseFloat(document.getElementById('vin').value);

    // Clamp operating point
    document.getElementById('vin').max = Vdd;
    Vin_op = Math.min(Vin_op, Vdd);

    // Display labels
    document.getElementById('val-vdd').textContent = Vdd.toFixed(1) + ' V';
    document.getElementById('val-vtn').textContent = Vtn.toFixed(1) + ' V';
    document.getElementById('val-vtp').textContent = Vtp.toFixed(1) + ' V';
    document.getElementById('val-kr').textContent  = Kr.toFixed(1);
    document.getElementById('val-vin').textContent = Vin_op.toFixed(2) + ' V';

    // Compute switching threshold
    const Vm       = calculateVm(Vdd, Vtn, Vtp, Kr);
    const Vout_max = Vm + Vtp;
    const Vout_min = Vm - Vtn;

    document.getElementById('val-vm').textContent  = Vm.toFixed(3) + ' V';
    document.getElementById('exp-vm').textContent   = Vm.toFixed(3) + ' V';
    document.getElementById('exp-vmax').textContent = Vout_max.toFixed(3) + ' V';
    document.getElementById('exp-vmin').textContent = Vout_min.toFixed(3) + ' V';

    // VTC data
    const vtcData = generateAnalyticalVTC(Vdd, Vtn, Vtp, Kr);

    // Find Vout at operating point
    let Vout_op;
    if (Math.abs(Vin_op - Vm) < 0.015) {
        Vout_op = Vdd / 2;
    } else {
        const nearest = vtcData.reduce((prev, curr) =>
            Math.abs(curr.x - Vin_op) < Math.abs(prev.x - Vin_op) ? curr : prev
        );
        Vout_op = nearest.y;
    }

    vtcChart.data.datasets[0].data = vtcData;
    vtcChart.data.datasets[1].data = [{ x: Vin_op, y: Vout_op, r: 8 }];

    // State
    const { region, nmos, pmos } = getRegionForVin(Vin_op, Vtn, Vtp, Vdd, Vm);
    setStateDisplay(region, nmos, pmos);

    // Transient
    const mode = document.getElementById('inputType').value;
    const { transVin, transVout } = runTransient(Vdd, Vtn, Vtp, Kn, Kp, mode);
    transChart.data.datasets[0].data = transVin;
    transChart.data.datasets[1].data = transVout;

    // Scale axes
    vtcChart.options.scales.x.max = Vdd + 0.1;
    vtcChart.options.scales.y.max = Vdd + 0.4;
    vtcChart.options.scales.x.min = 0;
    transChart.options.scales.y.max = Vdd + 0.4;

    vtcChart.update('none');
    transChart.update('none');
}

// ── EVENT LISTENERS ──
document.querySelectorAll('input, select').forEach(el =>
    el.addEventListener('input', updateSimulation)
);

// Initial render
updateSimulation();
